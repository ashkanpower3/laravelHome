<?php echo e(strtoupper('hello world')); ?>

<?php /**PATH C:\xampp\htdocs\angular\resources\views/home.blade.php ENDPATH**/ ?>