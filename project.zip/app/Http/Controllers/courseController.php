<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class courseController extends Controller
{
    public function index()
    {
        $courses = Course::latest()->filter(request(["search"]));
//        $courses = Course::latest()->whereNotNull("category_id");
//        if (request("search")) {
//            $courses->where("title", "like", '%' . request("search") . '%');
//        }
        return view("welcome", ['courses' => $courses->get()]);
    }


    public function course_details(Course $course){
        return view("course-details", ['course' => $course]);
    }
}
